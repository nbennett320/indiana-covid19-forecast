#! /usr/bin/python3
import os
os.system("wget --no-check-certificate 'https://docs.google.com/uc?export=download&id=1XZNLKoJPyroJfmxWc-ULDkxa8lwK5Ubi' -O usdss_diabetes.csv")