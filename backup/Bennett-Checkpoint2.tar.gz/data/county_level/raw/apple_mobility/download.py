#! /usr/bin/python3

# load in directly from apple to get most up-to-date data

pass