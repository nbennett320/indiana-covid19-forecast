#! /usr/bin/python3
import os
os.system("wget https://opendata.arcgis.com/datasets/cbd68d9887574a10bc89ea4efe2b8087_1.csv -O cdc_svi.csv")