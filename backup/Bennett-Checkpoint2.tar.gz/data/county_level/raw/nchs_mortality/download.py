#! /usr/bin/python3
import os
os.system("wget --no-check-certificate 'https://docs.google.com/uc?export=download&id=11Oy2IEfkeIgA0s5VZTZ4c3obg5A_IQDq' -O nchs_mortality.txt")