#! /usr/bin/python3
import os
os.system("wget --no-check-certificate 'https://docs.google.com/uc?export=download&id=1Hx7a2XfGVZyP1PT7RVR_mknAIVpDpQPf' -O dhdsp_stroke.csv")