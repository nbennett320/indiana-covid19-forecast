#! /usr/bin/python3
import os
os.system("wget --no-check-certificate 'https://docs.google.com/uc?export=download&id=140d4U-YJs7pnSYQ3Q1nEIX5NKbUNz-ze' -O mit_voting.csv")