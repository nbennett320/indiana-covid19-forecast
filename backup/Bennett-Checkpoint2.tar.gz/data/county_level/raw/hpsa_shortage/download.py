#! /usr/bin/python3
import os
os.system("wget https://data.hrsa.gov/DataDownload/DD_Files/BCD_HPSA_FCT_DET_PC.xlsx -O hpsa_shortage.xlsx")