#! /usr/bin/python3
import os
os.system("wget --no-check-certificate 'https://docs.google.com/uc?export=download&id=1c1sUSdV7Vu7x6aqdJVMGX_fpTK9homHZ' -O dhdsp_heart.csv")