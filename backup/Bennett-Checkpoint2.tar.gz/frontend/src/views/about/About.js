import React from 'react'

const About = props => {
  return (
    <div>
      
    </div>
  )
}

export default About