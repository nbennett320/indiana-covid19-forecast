import React from 'react'
import MapLayers from './MapLayers'

const Map = props => {
  return (
    <MapLayers {...props} />
  )
}

export default Map